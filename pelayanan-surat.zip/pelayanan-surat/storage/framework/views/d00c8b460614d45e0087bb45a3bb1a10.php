<?php if (isset($component)) { $__componentOriginal51da7a32851521952e1d3cb2ae8a8f80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal51da7a32851521952e1d3cb2ae8a8f80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-login','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-login'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form method="POST" action="<?php echo e(route('login.admin')); ?>">
        <h1 class="h6 text-center mb-3">Login Admin</h1>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($e); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="inputUsername">Username</label>
            <input type="text" name="username" value="<?php echo e(old('username')); ?>" class="form-control form-control-lg"
                placeholder="Masukkan Username" >
        </div>
        <div class="form-group">
            <label for="inputPassword">Password</label>
            <input type="password" name="password" class="form-control form-control-lg" placeholder="Masukkan Password">
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>
        <p class="mt-4 mb-0 text-muted text-center">© 2025</p>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal51da7a32851521952e1d3cb2ae8a8f80)): ?>
<?php $attributes = $__attributesOriginal51da7a32851521952e1d3cb2ae8a8f80; ?>
<?php unset($__attributesOriginal51da7a32851521952e1d3cb2ae8a8f80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal51da7a32851521952e1d3cb2ae8a8f80)): ?>
<?php $component = $__componentOriginal51da7a32851521952e1d3cb2ae8a8f80; ?>
<?php unset($__componentOriginal51da7a32851521952e1d3cb2ae8a8f80); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/admin/login.blade.php ENDPATH**/ ?>