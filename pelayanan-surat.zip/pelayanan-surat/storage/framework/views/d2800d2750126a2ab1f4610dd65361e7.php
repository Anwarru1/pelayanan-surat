<?php if (isset($component)) { $__componentOriginal51da7a32851521952e1d3cb2ae8a8f80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal51da7a32851521952e1d3cb2ae8a8f80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout-login','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout-login'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form method="POST" action="<?php echo e(route('login.pengguna')); ?>" id="formLoginPengguna">
        <?php echo csrf_field(); ?>

        <h1 class="h6 text-center mb-3">Login</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($e); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="form-group">
            <label for="inputUsername">NIK</label>
            <input type="text" name="nik" id="inputUsername" value="<?php echo e(old('nik')); ?>"
                class="form-control form-control-lg <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan NIK">
        </div>

        <div class="form-group">
            <label for="inputPassword">Password</label>
            <input type="password" name="password" id="inputPassword"
                class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan Password">
        </div>


        <div class="d-flex justify-content-between mb-3">
            <a href="<?php echo e(route('otp.request.form')); ?>">Lupa Password?</a>
            <a href="<?php echo e(route('pengguna.register')); ?>">Daftar akun</a>
        </div>

        <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>

        <p class="mt-4 mb-0 text-muted text-center">© 2025</p>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal51da7a32851521952e1d3cb2ae8a8f80)): ?>
<?php $attributes = $__attributesOriginal51da7a32851521952e1d3cb2ae8a8f80; ?>
<?php unset($__attributesOriginal51da7a32851521952e1d3cb2ae8a8f80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal51da7a32851521952e1d3cb2ae8a8f80)): ?>
<?php $component = $__componentOriginal51da7a32851521952e1d3cb2ae8a8f80; ?>
<?php unset($__componentOriginal51da7a32851521952e1d3cb2ae8a8f80); ?>
<?php endif; ?>


<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const form = document.getElementById('formLoginPengguna');
        if (!form) return;

        const fields = {
            nik: 'NIK',
            password: 'Password'
        };

        form.addEventListener('submit', function (e) {
            let isValid = true;

            // Bersihkan error sebelumnya
            form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
            form.querySelectorAll('.invalid-feedback.client-side').forEach(el => el.remove());

            Object.keys(fields).forEach(field => {
                const input = form.querySelector(`[name="${field}"]`);
                if (!input) return;

                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('is-invalid');

                    const error = document.createElement('div');
                    error.className = 'invalid-feedback client-side';
                    error.textContent = fields[field] + ' wajib diisi';
                    input.parentNode.appendChild(error);
                }
            });

            if (!isValid) {
                e.preventDefault(); // Hentikan submit jika ada error
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/pengguna/login.blade.php ENDPATH**/ ?>