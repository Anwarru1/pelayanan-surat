<div>
    
    <div wire:loading wire:target="search" class="text-muted mb-2">
        <i class="spinner-border spinner-border-sm"></i> Mencari...
    </div>

    
    <div class="toolbar row mb-3 align-items-center">
        <div class="col-md-6 d-flex">
            
            <input wire:model.defer="search"
                   type="text"
                   class="form-control"
                   placeholder="Cari nama atau NIK..."
                   style="max-width: 250px;">

            
            <button wire:click="$refresh"
                    class="btn btn-secondary ml-2"
                    style="height: calc(1.5em + .75rem + 2px);">
                Cari
            </button>
        </div>

        
        <div class="col-md-6 text-right">
            <form wire:submit.prevent="bulkDelete" class="d-inline">
                <button type="submit" class="btn btn-danger"
                        onclick="return confirm('Yakin hapus data terpilih?')"
                        wire:loading.attr="disabled"
                        wire:target="bulkDelete">
                    <span wire:loading.remove wire:target="bulkDelete">
                        <i class="fe fe-trash-2"></i>
                    </span>
                    <span wire:loading wire:target="bulkDelete">
                        <i class="spinner-border spinner-border-sm"></i>
                    </span>
                </button>
            </form>

            <button type="button" class="btn btn-primary ml-2" data-toggle="modal" data-target="#storePengguna">
                Tambah +
            </button>
        </div>
        <?php if (isset($component)) { $__componentOriginal112981bd646252494e3202bfb143c5eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal112981bd646252494e3202bfb143c5eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pengguna','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pengguna'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal112981bd646252494e3202bfb143c5eb)): ?>
<?php $attributes = $__attributesOriginal112981bd646252494e3202bfb143c5eb; ?>
<?php unset($__attributesOriginal112981bd646252494e3202bfb143c5eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal112981bd646252494e3202bfb143c5eb)): ?>
<?php $component = $__componentOriginal112981bd646252494e3202bfb143c5eb; ?>
<?php unset($__componentOriginal112981bd646252494e3202bfb143c5eb); ?>
<?php endif; ?>
    </div>


    
    <?php
        function highlight($text, $keyword) {
            if (!$keyword) return e($text);
            return preg_replace('/(' . preg_quote($keyword, '/') . ')/i', '<mark>$1</mark>', e($text));
        }
    ?>

    
    <table class="table table-bordered table-striped" id="penggunaLivewireTable">
        <thead class="thead-dark">
            <tr>
                <th>
                    <input type="checkbox" wire:click="$toggle('selectAllCheckbox')" wire:model="selectAllCheckbox">
                </th>
                <th>ID</th>
                <th>Nama</th>
                <th>NIK</th>
                <th>Password</th>
                <th>Jenis Kelamin</th>
                <th>Alamat</th>
                <th>TTL</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody wire:loading.class="opacity-50" wire:loading.remove.class="opacity-100">
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $penggunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengguna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <input type="checkbox" wire:model="selectedPenggunas" value="<?php echo e($pengguna->id); ?>">
                    </td>
                    <td><?php echo e($pengguna->id); ?></td>
                    <td><?php echo highlight($pengguna->nama, $search); ?></td>
                    <td><?php echo highlight($pengguna->nik, $search); ?></td>
                    <td>••••••••</td> 
                    <td><?php echo e($pengguna->j_kel); ?></td>
                    <td><?php echo e(Str::limit($pengguna->alamat, 10, '...')); ?></td>
                    <td><?php echo e($pengguna->tmp_lahir); ?>, <?php echo e(\Carbon\Carbon::parse($pengguna->tgl_lahir)->format('d-m-Y')); ?></td>
                    <td>
                        <button type="button" class="btn btn-sm btn-warning" data-toggle="modal" data-target="#editPengguna<?php echo e($pengguna->id); ?>">
                            Edit
                        </button>
                        <?php if (isset($component)) { $__componentOriginal5ac469103065242c2c4a4fcd8ff353f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ac469103065242c2c4a4fcd8ff353f2 = $attributes; } ?>
<?php $component = App\View\Components\EditPengguna::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('edit-pengguna'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\EditPengguna::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pengguna' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pengguna)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ac469103065242c2c4a4fcd8ff353f2)): ?>
<?php $attributes = $__attributesOriginal5ac469103065242c2c4a4fcd8ff353f2; ?>
<?php unset($__attributesOriginal5ac469103065242c2c4a4fcd8ff353f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ac469103065242c2c4a4fcd8ff353f2)): ?>
<?php $component = $__componentOriginal5ac469103065242c2c4a4fcd8ff353f2; ?>
<?php unset($__componentOriginal5ac469103065242c2c4a4fcd8ff353f2); ?>
<?php endif; ?>

                        <form action="<?php echo e(route('data-user.pengguna.destroy', $pengguna->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" onclick="return confirm('Hapus Pengguna ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center text-muted">Tidak ada data ditemukan.</td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    
    <div class="d-flex justify-content-end mt-3">
        <?php echo e($penggunas->links()); ?>

    </div>
</div>


<?php $__env->startPush('scripts'); ?>
<script>
    window.addEventListener('bulk-delete-success', () => {
        alert('Data berhasil dihapus!');
        // Atau pakai toast Bootstrap / SweetAlert di sini
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/livewire/pengguna-search.blade.php ENDPATH**/ ?>