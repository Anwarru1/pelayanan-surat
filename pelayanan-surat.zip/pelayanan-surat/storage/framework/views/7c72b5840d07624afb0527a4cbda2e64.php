<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<main role="main" class="main-content">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <h2 class="page-title">Form Pengajuan Surat</h2>
        <div class="card shadow mb-4">
          <div class="card-header">
            <strong class="card-title">Pengajuan Surat</strong>
          </div>
          <div class="card-body">
            <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul class="mb-0">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
              <div class="alert alert-success">
                <?php echo e(session('success')); ?>

              </div>
            <?php endif; ?>

            <form action="<?php echo e(route('ajukan-surat.store')); ?>" method="POST" enctype="multipart/form-data" id="formAjukanSurat">
              <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-md-12 mb-4">
                  <div class="form-group mb-3">
                    <label for="jenis_surat_id">Pilih Jenis Surat</label>
                    <select name="jenis_surat_id" id="jenis_surat_id" class="custom-select">
                      <option value="" selected disabled>Pilih jenis surat</option>
                      <?php $__currentLoopData = $ajukan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php echo e(old('jenis_surat_id') == $item->id ? 'selected' : ''); ?>>
                          <?php echo e($item->nama_jenis_surat); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>

                  <div class="form-group mb-3">
                    <label>Isi Syarat</label>
                    <div id="syarat-container">
                      
                    </div>
                  </div>

                  <div class="form-group row mb-0">
                    <div class="col-md-9 left">
                      <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> Ajukan Surat
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>


<script>
$(document).ready(function() {
  $('#jenis_surat_id').on('change', function() {
    const jenisSuratId = $(this).val();
    const container = $('#syarat-container');
    container.empty();

    if (jenisSuratId) {
      $.get(`/api/jenis-surat/${jenisSuratId}`, function(data) {
        data.syarat.forEach((syarat) => {
          const inputName = syarat.replace(/\s+/g, '_');
          const label = `<label for="syarat_${inputName}">${syarat}</label>`;

          if (['bidang_usaha', 'jenis_usaha', 'mulai_usaha', 'keperluan'].includes(syarat.toLowerCase())) {
            container.append(`
              <div class="form-group">
                ${label}
                <input type="text" name="syarat[${syarat}]" class="form-control" id="syarat_${inputName}">
              </div>
            `);
          } else if (syarat.toLowerCase() === 'keterangan') {
            const defaultValue = data.keterangan_default ?? '';
            container.append(`
              <div class="form-group">
                ${label}
                <textarea name="syarat[${syarat}]" class="form-control" id="syarat_${inputName}">${defaultValue}</textarea>
              </div>
            `);
          } else {
            container.append(`
              <div class="form-group">
                ${label}
                <input type="file" name="syarat[${syarat}]" class="form-control-file" id="syarat_${inputName}">
              </div>
            `);
          }
        });
      });
    }
  });
});
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('formAjukanSurat');
  form.addEventListener('submit', function (e) {
    let isValid = true;

    // Reset error
    form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
    form.querySelectorAll('.invalid-feedback').forEach(el => el.remove());

    const jenisSurat = document.getElementById('jenis_surat_id');
    if (!jenisSurat.value) {
      showError(jenisSurat, 'Jenis surat wajib dipilih.');
      isValid = false;
    }

    const syaratInputs = document.querySelectorAll('#syarat-container input, #syarat-container textarea');
    syaratInputs.forEach(input => {
      if (!input.value || input.value.trim() === '') {
        showError(input, 'Field ini wajib diisi.');
        isValid = false;
      }
    });

    if (!isValid) {
      e.preventDefault();
    }

    function showError(input, msg) {
      input.classList.add('is-invalid');
      const feedback = document.createElement('div');
      feedback.className = 'invalid-feedback';
      feedback.innerText = msg;
      input.parentNode.appendChild(feedback);
    }
  });
});
</script>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/pengguna/ajukan-surat.blade.php ENDPATH**/ ?>