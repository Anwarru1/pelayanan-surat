<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['pesanBaru']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['pesanBaru']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<nav class="topnav navbar navbar-light">
  <button type="button" class="navbar-toggler text-muted mt-2 p-0 mr-3 collapseSidebar">
    <i class="fe fe-menu navbar-toggler-icon"></i>
  </button>

  <form class="form-inline mr-auto searchform text-muted">
    <input class="form-control mr-sm-2 bg-transparent border-0 pl-4 text-muted" 
           type="search" placeholder="Cari sesuatu..." aria-label="Search">
  </form>

  <ul class="nav align-items-center">
    <!-- Mode Switcher -->
    <li class="nav-item">
      <a class="nav-link text-muted" href="#" id="modeSwitcher" data-mode="light">
        <i class="fe fe-sun fe-16"></i>
      </a>
    </li>

    <!-- Dropdown Pesan -->
    <?php if(auth()->guard('admin')->check()): ?>
      <?php if(Route::has('admin.pesan')): ?>
        <li class="nav-item dropdown d-flex align-items-center mx-2">
          <a class="nav-link dropdown-toggle text-muted pr-0" href="#" role="button" data-toggle="dropdown">
            <i class="fe fe-mail"></i>
            <?php if($pesanBaru->count() > 0): ?>
              <span class="dot dot-md bg-danger"></span>
            <?php endif; ?>
          </a>

          <div class="dropdown-menu dropdown-menu-right">
            <h6 class="dropdown-header">Pesan Terbaru</h6>
            <?php $__empty_1 = true; $__currentLoopData = $pesanBaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <a class="dropdown-item" href="<?php echo e(route('admin.pesan')); ?>">
                <strong><?php echo e($pesan->pengguna->nama); ?></strong>: 
                <?php echo e(\Illuminate\Support\Str::limit($pesan->isi, 30)); ?>

              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <a class="dropdown-item text-muted" href="<?php echo e(route('admin.pesan')); ?>">
                Tidak ada pesan baru
              </a>
            <?php endif; ?>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item text-center text-primary" href="<?php echo e(route('admin.pesan')); ?>">
              Lihat Semua Pesan
            </a>
          </div>
        </li>
      <?php endif; ?>
    <?php endif; ?>


    <!-- Logout -->
    <li class="nav-item mx-2 d-flex align-items-center">
      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-sm btn-outline-danger">
          <i class="fe fe-log-out"></i> Logout
        </button>
      </form>
    </li>
  </ul>
</nav>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/components/navbar.blade.php ENDPATH**/ ?>