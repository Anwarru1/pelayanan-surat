<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<!--Main Content-->
      <main role="main" class="main-content">
        <div class="container-fluid">
          <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Jenis Surat</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <div class="card shadow">
                    <div class="card-body">
                        <div class="toolbar row mb-3">
                        <div class="col ml-auto">
                          <div class="dropdown float-right">
                            <button type="button" class="btn btn-primary ml-3 float-right" data-toggle="modal" data-target="#tambahJenisSurat" data-whatever="@mdo">Tambah +</button>
                            <?php if (isset($component)) { $__componentOriginal7b4353ba263dbe824ca7648d2560a2c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b4353ba263dbe824ca7648d2560a2c6 = $attributes; } ?>
<?php $component = App\View\Components\TambahJenisSurat::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tambah-jenis-surat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TambahJenisSurat::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b4353ba263dbe824ca7648d2560a2c6)): ?>
<?php $attributes = $__attributesOriginal7b4353ba263dbe824ca7648d2560a2c6; ?>
<?php unset($__attributesOriginal7b4353ba263dbe824ca7648d2560a2c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b4353ba263dbe824ca7648d2560a2c6)): ?>
<?php $component = $__componentOriginal7b4353ba263dbe824ca7648d2560a2c6; ?>
<?php unset($__componentOriginal7b4353ba263dbe824ca7648d2560a2c6); ?>
<?php endif; ?>
                          </div>
                        </div>
                      </div>
                      <!-- table -->
                      <table class="table datatables" id="dataTable-1">
                        <thead class="thead-dark">
                          <tr>
                            <th></th>
                            <th>Kode Surat</th>
                            <th>Nama Jenis Surat</th>
                            <th>Syarat</th>
                            <th>Template</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $jenisSurat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td>
                              <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input">
                                <label class="custom-control-label"></label>
                              </div>
                            </td>
                            <td><?php echo e($s->kode_surat); ?></td>
                            <td><?php echo e($s->nama_jenis_surat); ?></td>
                            <td>
                              <ul>
                                <?php $__currentLoopData = $s->syarat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $syarat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($syarat); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            </td>
                            <td>
                              <?php if($s->template): ?>
                                <a href="<?php echo e(asset('storage/' . $s->template)); ?>" target="_blank">Lihat Template</a>
                              <?php else: ?>
                                -
                              <?php endif; ?>
                            </td>
                            <td>
                              <button type="button" class="btn btn-sm btn-warning" data-toggle="modal" data-target="#editJenisSurat<?php echo e($s->id); ?>">Edit</button>
                              <?php if (isset($component)) { $__componentOriginal303c58eb2eeee2b7f9a25e058636630a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal303c58eb2eeee2b7f9a25e058636630a = $attributes; } ?>
<?php $component = App\View\Components\EditJenisSurat::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('edit-jenis-surat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\EditJenisSurat::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['s' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($s)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal303c58eb2eeee2b7f9a25e058636630a)): ?>
<?php $attributes = $__attributesOriginal303c58eb2eeee2b7f9a25e058636630a; ?>
<?php unset($__attributesOriginal303c58eb2eeee2b7f9a25e058636630a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal303c58eb2eeee2b7f9a25e058636630a)): ?>
<?php $component = $__componentOriginal303c58eb2eeee2b7f9a25e058636630a; ?>
<?php unset($__componentOriginal303c58eb2eeee2b7f9a25e058636630a); ?>
<?php endif; ?>
                              <form action="<?php echo e(route('jenis-surat.destroy', $s->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button onclick="return confirm('Hapus Jenis Surat ini?')" class="btn btn-sm btn-danger">Hapus</button>
                              </form>  
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> 
      <!-- main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/admin/jenis-surat.blade.php ENDPATH**/ ?>