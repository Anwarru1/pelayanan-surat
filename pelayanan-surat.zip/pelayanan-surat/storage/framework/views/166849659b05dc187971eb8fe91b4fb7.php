<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<main class="main-content">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <h2 class="mb-2 page-title">Laporan</h2>

        <div class="card shadow-sm mb-4">
          <div class="card-body">
            <form method="GET" action="<?php echo e(route('laporan.index')); ?>" class="mb-4">
              <div class="row">
                <div class="col-md-3">
                  <select name="bulan" class="form-control">
                    <option value="">Pilih Bulan</option>
                    <?php $__currentLoopData = range(1,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($b); ?>" <?php echo e(request('bulan') == $b ? 'selected' : ''); ?>>
                        <?php echo e(\Carbon\Carbon::create()->month($b)->translatedFormat('F')); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="col-md-3">
                  <select name="tahun" class="form-control">
                    <option value="">Pilih Tahun</option>
                    <?php $__currentLoopData = range(now()->year, 2020); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($t); ?>" <?php echo e(request('tahun') == $t ? 'selected' : ''); ?>><?php echo e($t); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="col-md-2">
                  <button type="submit" class="btn btn-primary">Filter</button>
                </div>
              </div>
            </form>

            <div class="mb-3">
              <a href="<?php echo e(route('laporan.print', request()->all())); ?>" class="btn btn-secondary" target="_blank">
                <i class="fe fe-printer mr-1"></i> Print
              </a>
              <a href="<?php echo e(route('laporan.export.excel', request()->all())); ?>" class="btn btn-success">
                <i class="fe fe-file-text mr-1"></i> Excel
              </a>
              <a href="<?php echo e(route('laporan.export.pdf', request()->all())); ?>" class="btn btn-warning">
                <i class="fe fe-file mr-1"></i> PDF
              </a>
            </div>

            <div class="table-responsive">
              <table class="table datatable" id="laporanTable">
                <thead class="thead-dark text-center">
                  <tr>
                    <th>No</th>
                    <th>Nama Pemohon</th>
                    <th>Jenis Surat</th>
                    <th>Tanggal Pengajuan</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($key + 1); ?></td>
                      <td><?php echo e($row->pengguna->nama); ?></td>
                      <td><?php echo e($row->nama_jenis_surat); ?></td>
                      <td><?php echo e(\Carbon\Carbon::parse($row->tanggal)->translatedFormat('l, d F Y')); ?></td>
                      <td>
                        <?php if($row->status == 'menunggu'): ?>
                          <span class="badge badge-warning">Menunggu</span>
                        <?php elseif($row->status == 'diproses'): ?>
                          <span class="badge badge-info">Diproses</span>
                        <?php elseif($row->status == 'diterima'): ?>
                          <span class="badge badge-success">Selesai</span>
                        <?php else: ?>
                          <span class="badge badge-danger">Ditolak</span>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="text-center">Tidak ada data</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div> <!-- .col-12 -->
    </div> <!-- .row -->
  </div> <!-- .container-fluid -->
</main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/admin/laporan.blade.php ENDPATH**/ ?>