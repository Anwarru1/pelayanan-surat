<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<!--Main Content-->
<main role="main" class="main-content">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <h2 class="mb-2 page-title">List Surat</h2>
        <div class="row my-4">
          <!-- Small table -->
          <div class="col-md-12">
            <div class="card shadow">
              <div class="card-body">
                <div class="toolbar row mb-3">
                  <div class="col ml-auto">
                    <div class="dropdown float-left">
                      <a href="<?php echo e(route('ajukan-surat.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Ajukan Surat Baru
                      </a>
                    </div>
                  </div>
                </div>
                <!-- table -->
                <table class="table datatables" id="listSuratTable">
                  <thead class="thead-dark">
                    <tr>
                      <th></th>
                      <th>Id</th>
                      <th>Jenis Surat</th>
                      <th>Tanggal Pengajuan</th>
                      <th>Status</th>
                      <th>Keterangan</th>
                      <th>Lihat Surat</th>
                      <th>Download Surat</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $ajukan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengajuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td>
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input">
                          <label class="custom-control-label"></label>
                        </div>
                      </td>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($pengajuan->jenisSurat->nama_jenis_surat); ?></td>
                      <td><?php echo e(\Carbon\Carbon::parse($pengajuan->tanggal)->translatedFormat('l, d F Y')); ?></td>
                      <td>
                        <?php if($pengajuan->status == 'menunggu'): ?>
                          <span class="badge badge-warning">Menunggu</span>
                        <?php elseif($pengajuan->status == 'diproses'): ?>
                          <span class="badge badge-info">Diproses</span>
                        <?php elseif($pengajuan->status == 'diterima'): ?>
                          <span class="badge badge-success">Selesai</span>
                        <?php else: ?>
                          <span class="badge badge-danger">Ditolak</span>
                        <?php endif; ?>
                      </td>
                      <td><?php echo e($pengajuan->keterangan); ?></td>

                      <?php if($pengajuan->status === 'diterima'): ?>
                        <?php
                          $berkas = \App\Models\BerkasSurat::where('pengajuan_surat_id', $pengajuan->id)->first();
                        ?>
                        <?php if($berkas && $berkas->file_surat): ?>
                          <td>
                            <a href="<?php echo e(asset('storage/' . $berkas->file_surat)); ?>" target="_blank" class="btn btn-sm btn-primary">
                              <i class="fe fe-eye"></i> Lihat
                            </a>
                          </td>
                          <td>
                            <a href="<?php echo e(asset('storage/' . $berkas->file_surat)); ?>" download class="btn btn-sm btn-success">
                              <i class="fe fe-download"></i> Download
                            </a>
                          </td>
                        <?php else: ?>
                          <td></td>
                          <td></td>
                        <?php endif; ?>
                      <?php else: ?>
                        <td></td>
                        <td></td>
                      <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td colspan="8" class="text-center">Belum ada pengajuan surat</td>
                    </tr>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div> <!-- simple table -->
        </div> <!-- end section -->
      </div> <!-- .col-12 -->
    </div> <!-- .row -->
  </div> <!-- .container-fluid -->
</main> <!-- main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<!-- Tambahkan style opsional untuk geser search ke kiri -->
<style>
  #listSuratTable_filter {
    float: left !important;
    text-align: left;
  }
</style>

<script>
$(document).ready(function () {
    var table = $('#listSuratTable').DataTable({
        responsive: true,
        paging: false,        // Nonaktifkan pagination
        info: false,          // Nonaktifkan info entries
        lengthChange: false,  // Nonaktifkan dropdown jumlah entries
        language: {
            searchPlaceholder: "Cari...",
            search: ""
        },
        columnDefs: [{
            orderable: false,
            targets: [0, 5] // Kolom yang tidak bisa di-sort
        }],
        dom: '<"top"f>rt' // Hanya search (filter) di bagian atas
    });

    // Pastikan filter berada di kiri
    $('#listSuratTable_filter').addClass('float-left');
});
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/pengguna/list-surat.blade.php ENDPATH**/ ?>