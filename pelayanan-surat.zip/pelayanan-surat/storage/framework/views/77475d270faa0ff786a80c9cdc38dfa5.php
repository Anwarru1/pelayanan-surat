<!-- Modal -->
<div class="modal fade" id="kelolaModal<?php echo e($p->id); ?>" tabindex="-1" role="dialog" aria-labelledby="kelolaModalLabel<?php echo e($p->id); ?>" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Kelola Pengajuan Surat</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span>&times;</span>
        </button>
      </div>

      <div class="modal-body">
        <?php if(session('modal_id') == 'kelolaModal' . $p->id && session('success_nomor')): ?>
          <div class="alert alert-success">
            <?php echo e(session('success_nomor')); ?>

          </div>
        <?php endif; ?>
        
        <table class="table table-bordered">
          <tr>
            <th>Nama Pemohon</th>
            <td><?php echo e($p->pengguna->nama); ?></td>
          </tr>
          <tr>
            <th>Jenis Surat</th>
            <td><?php echo e($p->nama_jenis_surat); ?></td>
          </tr>
          <tr>
            <th>Berkas Syarat</th>
            <td>
                <?php
                    $syarat = json_decode($p->data_tambahan, true);
                ?>
                <ul>
                <?php $__currentLoopData = $syarat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_string($value) && Str::startsWith($value, 'syarat-pengajuan/')): ?>
                    <li>
                        <strong><?php echo e($key); ?>:</strong>
                        <a href="<?php echo e(asset('storage/' . $value)); ?>" target="_blank">Lihat Berkas</a>
                    </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </td>
          </tr>
          <tr>
            <th>Status</th>
            <td>
              <?php if($p->status == 'menunggu'): ?>
                <span class="badge badge-warning">Menunggu</span>
                  <?php elseif($p->status == 'diproses'): ?>
                <span class="badge badge-info">Diproses</span>
                  <?php elseif($p->status == 'diterima'): ?>
                <span class="badge badge-success">Selesai</span>
                  <?php else: ?>
                <span class="badge badge-danger">Ditolak</span>
              <?php endif; ?>
            </td>
          </tr>
          <tr>
            <th>Tanggal Pengajuan</th>
            <td><?php echo e(\Carbon\Carbon::parse($p->tanggal)->translatedFormat('l, d F Y')); ?></td>
          </tr>
          <tr>
            <th>Nomor Urutan Surat</th>
            <td>
              <form action="<?php echo e(route('pengajuan-surat.nomor-urut', $p->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <label>Nomor Urut Surat</label>
                  <input type="number" name="nomor_urutan" class="form-control" value="<?php echo e($p->nomor_urutan); ?>" id="nomorUrut<?php echo e($p->id); ?>">
                  <button type="submit" class="btn btn-sm btn-primary mt-2">Simpan</button>
              </form>
            </td>
          </tr>
        </table>

        
        <div class="mt-3">
          <?php
              $berkas = \App\Models\BerkasSurat::where('pengajuan_surat_id', $p->id)->first();
              $nomorFilled = !empty($p->nomor_urutan);
          ?>

          <?php if($berkas && $berkas->file_surat): ?>
            <a href="<?php echo e(asset('storage/' . $berkas->file_surat)); ?>" class="btn btn-info" target="_blank">
              <i class="fe fe-eye"></i> Lihat Surat
            </a>
          <?php endif; ?>
          
          <a href="<?php echo e(route('pengajuan-surat.preview', $p->id)); ?>" 
            class="btn btn-secondary <?php echo e(!$nomorFilled ? 'disabled' : ''); ?>" 
            <?php echo e(!$nomorFilled ? 'aria-disabled=true' : ''); ?> 
            id="btnPreview<?php echo e($p->id); ?>">
            <i class="fe fe-file-text"></i> Generate Surat
          </a>

          
          <?php if($p->status === 'menunggu'): ?>
            <button class="btn btn-danger" onclick="showForm('tolakForm<?php echo e($p->id); ?>')">Tolak</button>
            <button class="btn btn-success" onclick="validateTerima('<?php echo e($p->id); ?>')" id="btnTerimaTrigger<?php echo e($p->id); ?>">Terima</button>
          <?php endif; ?>
        </div>

        
          <form action="<?php echo e(route('pengajuan-surat.tolak', $p->id)); ?>" method="POST" id="tolakForm<?php echo e($p->id); ?>" class="mt-3 d-none">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
              <label>Alasan Penolakan</label>
              <textarea name="keterangan" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-danger">Kirim Penolakan</button>
          </form>

          
          <form action="<?php echo e(route('pengajuan-surat.terima', $p->id)); ?>" method="POST" id="terimaForm<?php echo e($p->id); ?>" class="mt-3 d-none">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="status" value="diproses">
            <button type="submit" class="btn btn-success">Konfirmasi & Proses</button>
          </form>
      </div>
    </div>
  </div>
</div>


<?php $__env->startPush('scripts'); ?>
<script>
  function showForm(id) {
    const tolak = document.getElementById('tolakForm<?php echo e($p->id); ?>');
    const terima = document.getElementById('terimaForm<?php echo e($p->id); ?>').classList.add('d-none');
    tolak.classList.add('d-none');
    document.getElementById(id).classList.remove('d-none');
  }

  function validateTerima(id) {
    const nomorInput = document.getElementById('nomorUrut' + id);
    if (!nomorInput.value.trim()) {
      alert('Silakan isi nomor urutan surat terlebih dahulu sebelum menerima.');
    } else {
      showForm('terimaForm' + id);
    }
  }

  // Auto show modal if session has 'modal_id'
  <?php if(session('modal_id')): ?>
    $(document).ready(function() {
      $('#<?php echo e(session('modal_id')); ?>').modal('show');
    });
  <?php endif; ?>
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/components/detail-pengajuan.blade.php ENDPATH**/ ?>