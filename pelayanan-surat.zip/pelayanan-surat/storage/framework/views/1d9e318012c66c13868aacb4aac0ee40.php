<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pesanBaru' => $pesanBaru]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pesanBaru' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pesanBaru)]); ?>
  <!--Main Content-->
      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <div class="row">
                <div class="col-md-6 col-xl-3 mb-4">
                  <div class="card shadow bg-primary text-white border-0">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-3 text-center">
                          <span class="circle circle-sm bg-primary-light">
                            <i class="fe fe-16 fe-mail text-white mb-0"></i>
                          </span>
                        </div>
                        <div class="col pr-0">
                          <p class="small text-muted mb-0">Pengajuan Surat</p>
                          <span class="h3 mb-0 text-white"><?php echo e($totalPengajuan); ?></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-xl-3 mb-4">
                  <div class="card shadow border-0">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-3 text-center">
                          <span class="circle circle-sm bg-primary">
                            <i class="fe fe-16 fe-check-circle text-white mb-0"></i>
                          </span>
                        </div>
                        <div class="col pr-0">
                          <p class="small text-muted mb-0">Dikonfirmasi</p>
                          <span class="h3 mb-0"><?php echo e($totalTerkonfirmasi); ?></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-xl-3 mb-4">
                  <div class="card shadow border-0">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-3 text-center">
                          <span class="circle circle-sm bg-primary">
                            <i class="fe fe-16 fe-x-circle text-white mb-0"></i>
                          </span>
                        </div>
                        <div class="col">
                          <p class="small text-muted mb-0">Belum Dikonfirmasi</p>
                          <div class="row align-items-center no-gutters">
                            <div class="col-auto">
                              <span class="h3 mr-2 mb-0"><?php echo e($totalBelumDikonfirmasi); ?></span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-xl-3 mb-4">
                  <div class="card shadow border-0">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-3 text-center">
                          <span class="circle circle-sm bg-primary">
                            <i class="fe fe-16 fe-users text-white mb-0"></i>
                          </span>
                        </div>
                        <div class="col">
                          <p class="small text-muted mb-0">Total Pengguna</p>
                          <span class="h3 mb-0"><?php echo e($totalPengguna); ?></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div> <!-- end section -->

              <div class="row my-4">

                <div class="col-md-3 d-flex flex-column gap-3">

                  <!-- Card: Role Saat Ini -->
                  <div class="card shadow-sm p-3 mb-3">
                    <h6 class="mb-2 fw-bold">Role Saat Ini</h6>
                    <?php
                      $role = Auth::user()->role ?? 'Tidak diketahui';
                    ?>
                    <span class="badge bg-primary text-white px-3 py-2"><?php echo e($role); ?></span>
                  </div>

                  <!-- Card: Aksi Cepat -->
                  <div class="card shadow-sm p-3 h-100">
                    <h6 class="mb-3 fw-bold">Aksi Cepat</h6>
                    <?php
                        $admin = Auth::guard('admin')->user();
                    ?>
                    <div class="d-flex flex-column gap-2">
                      <?php if($admin->role === 'admin'): ?>
                      <a href="<?php echo e(route('pengajuan.index')); ?>" class="btn btn-outline-primary btn-sm w-100 mb-2">
                        <i class="fe fe-plus mr-1"></i> Pengajuan Surat
                      </a>
                      <a href="<?php echo e(route('jenis-surat.index')); ?>" class="btn btn-outline-success btn-sm w-100 mb-2">
                        <i class="fe fe-folder mr-1"></i> Kelola Jenis Surat
                      </a>
                      <a href="<?php echo e(route('data-user.index')); ?>" class="btn btn-outline-warning btn-sm text-dark w-100">
                        <i class="fe fe-users mr-1"></i> Data User
                      </a>
                      <?php endif; ?>
                      <?php if($admin->role === 'kepala desa'): ?>
                      <a href="<?php echo e(route('berkas.index')); ?>" class="btn btn-outline-success btn-sm w-100 mb-2">
                        <i class="fe fe-folder mr-1"></i> Konfirmasi Surat
                      </a>
                      <a href="<?php echo e(route('laporan.index')); ?>" class="btn btn-outline-warning btn-sm text-dark w-100">
                        <i class="fe fe-users mr-1"></i> Buat Laporan
                      </a>
                      <?php endif; ?>
                    </div>
                  </div>

                </div>

                <!-- Kolom 2: Grafik Pengajuan -->
                <div class="col-md-9">
                  <div class="card shadow-sm p-3 h-100">
                    <h6 class="mb-3 text-center">Grafik Pengajuan per Bulan</h6>
                    <canvas id="pengajuanChart" height="200"></canvas>
                  </div>
                </div>

              </div>


              <div class="row my-2">
                <div class="col d-flex justify-content-start align-items-center">
                  <?php
                    $tanggal = \Carbon\Carbon::now()->translatedFormat('l, d F Y');
                  ?>

                  <p class="mb-0 text-muted">
                    <i class="fe fe-calendar mr-1"></i> <?php echo e($tanggal); ?>

                  </p>
                </div>
              </div>

              <div class="row">
                <!-- Recent orders -->
                <div class="col-md-12">
                  <div class="card shadow">
                    <div class="card-body">
                    <h6 class="mb-3">Pengajuan Surat Terbaru</h6>
                    <table class="table dashboard">
                      <thead class="thead-dark">
                        <tr>
                          <th>No.</th>
                          <th>Name</th>
                          <th>Jenis Surat</th>
                          <th>Tanggal Pengajuan</th>
                          <th>Status</th>
                          <th>Detail</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $pengajuanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($p->pengguna->nama); ?></td>
                          <td><?php echo e($p->jenisSurat->nama_jenis_surat); ?></td>
                          <td><?php echo e($p->tanggal); ?></td>
                          <td>
                            <?php if($p->status == 'menunggu'): ?>
                                  <span class="badge badge-warning">Menunggu</span>
                                <?php elseif($p->status == 'diproses'): ?>
                                    <span class="badge badge-info">Diproses</span>
                                <?php elseif($p->status == 'diterima'): ?>
                                    <span class="badge badge-success">Selesai</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Ditolak</span>
                                <?php endif; ?>
                          </td>
                          <td>
                            <a href="<?php echo e(route('pengajuan.index')); ?>" class="btn btn-sm btn-primary">
                              <i class="fe fe-eye"></i> Lihat Detail
                            </a>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    </div>
                  </div>
                </div> <!-- / .col-md-3 -->
              </div> <!-- end section -->
            </div>
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>

<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
  const ctx = document.getElementById('pengajuanChart').getContext('2d');
  const pengajuanChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
      datasets: [{
        label: 'Pengajuan',
        data: <?php echo json_encode($dataChart, 15, 512) ?>,
        backgroundColor: '#4e73df'
      }]
    },
    options: {
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            stepSize: 2
          }
        }
      }
    }
  });
</script>


    <?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>