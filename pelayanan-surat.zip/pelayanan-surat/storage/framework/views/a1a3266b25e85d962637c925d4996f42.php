<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <main role="main" class="main-content">
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-12">
          <h2 class="mb-2 page-title">Pesan Masuk</h2>
          <div class="row my-4">
            <div class="col-md-12">
              <div class="card shadow">
                <div class="card-body">
                  
                  <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                  <?php endif; ?>

                  <table class="table table-bordered table-hover">
                    <thead class="thead-dark">
                      <tr>
                        <th>No</th>
                        <th>Nama Pengguna</th>
                        <th>Subjek</th>
                        <th>Isi</th>
                        <th>Waktu</th>
                        <th>Status</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $pesanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($pesan->pengguna->nama); ?></td>
                          <td><?php echo e($pesan->subjek); ?></td>
                          <td>
                            <button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#modalIsi<?php echo e($pesan->id); ?>">
                              Lihat Isi
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="modalIsi<?php echo e($pesan->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modalLabel<?php echo e($pesan->id); ?>" aria-hidden="true">
                              <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="modalLabel<?php echo e($pesan->id); ?>">Isi Pesan dari <?php echo e($pesan->pengguna->nama); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <p><strong>Subjek:</strong> <?php echo e($pesan->subjek); ?></p>
                                    <p><?php echo e($pesan->isi); ?></p>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </td>
                          <td><?php echo e($pesan->created_at->format('d M Y H:i')); ?></td>
                          <td>
                            <?php if($pesan->is_read): ?>
                              <span class="badge badge-success">Dibaca</span>
                            <?php else: ?>
                              <span class="badge badge-warning">Baru</span>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if(!$pesan->is_read): ?>
                              <form action="<?php echo e(route('admin.pesan.baca', $pesan->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-primary">Tandai Dibaca</button>
                              </form>
                            <?php else: ?>
                              <i class="fe fe-check-circle text-success"></i>
                            <?php endif; ?>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

                </div>
              </div>
            </div> <!-- .col-md-12 -->
          </div> <!-- .row -->
        </div> <!-- .col-12 -->
      </div> <!-- .row justify-content-center -->
    </div> <!-- .container-fluid -->
  </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/admin/pesan.blade.php ENDPATH**/ ?>