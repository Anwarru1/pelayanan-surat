<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <main role="main" class="main-content">
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-12 col-lg-8">

          
          <div class="card shadow mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Informasi Profil</h5>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                <table class="table table-bordered">
                    <tbody>
                    <tr>
                        <td>Nama Lengkap</td>
                        <td><?php echo e(Auth::user()->nama); ?></td>
                    </tr>
                    <tr>
                        <td>NIK</td>
                        <td><?php echo e(Auth::user()->nik); ?></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td><?php echo e(Auth::user()->j_kel == 'Laki-laki' ? 'Laki-laki' : 'Perempuan'); ?></td>
                    </tr>
                    <tr>
                        <td>Tempat, Tanggal Lahir</td>
                        <td><?php echo e(Auth::user()->tmp_lahir); ?>, <?php echo e(\Carbon\Carbon::parse(Auth::user()->tgl_lahir)->format('d/m/Y')); ?></td>
                    </tr>
                    <tr>
                        <td>Agama</td>
                        <td><?php echo e(Auth::user()->agama); ?></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td><?php echo e(Auth::user()->status); ?></td>
                    </tr>
                    <tr>
                        <td>Pekerjaan</td>
                        <td><?php echo e(Auth::user()->pekerjaan); ?></td>
                    </tr>
                    <tr>
                        <td>Nomor HP</td>
                        <td><?php echo e(Auth::user()->nomor_hp); ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td><?php echo e(Auth::user()->alamat); ?></td>
                    </tr>
                    </tbody>
                </table>
                </div>

                <div class="text-right mt-3">
                <button class="btn btn-outline-secondary btn-sm" data-toggle="modal" data-target="#editProfilModal">
                    <i class="fe fe-edit"></i> Edit Profil
                </button>
                </div>
            </div>
            </div>


          
          <div class="card shadow">
            <div class="card-header">
              <h5 class="card-title mb-0">Ganti Password</h5>
            </div>
            <div class="card-body">
              <form action="<?php echo e(route('pengguna.profil.update-password')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                  <label for="current_password">Password Saat Ini</label>
                  <input type="password" name="current_password" id="current_password"
                         class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                  <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                  <label for="new_password">Password Baru</label>
                  <input type="password" name="new_password" id="new_password"
                         class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                  <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <small class="form-text text-muted">Minimal 8 karakter.</small>
                </div>

                <div class="form-group">
                  <label for="new_password_confirmation">Konfirmasi Password Baru</label>
                  <input type="password" name="new_password_confirmation" id="new_password_confirmation"
                         class="form-control" required>
                </div>

                <div class="text-right">
                  <button type="submit" class="btn btn-primary">
                    <i class="fe fe-save"></i> Simpan Password
                  </button>
                </div>
              </form>
            </div>
          </div>

        </div>
      </div>
    </div>
  </main>

  
  <div class="modal fade" id="editProfilModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Profil</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Tutup">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <form action="<?php echo e(route('pengguna.profil.update')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>

          <div class="modal-body">
            <div class="form-group">
              <label for="nama">Nama Lengkap</label>
              <input type="text" id="nama" name="nama" class="form-control" value="<?php echo e(Auth::user()->nama); ?>" required>
            </div>

            <div class="form-group">
              <label for="alamat">Alamat</label>
              <textarea id="alamat" name="alamat" class="form-control" rows="3" required><?php echo e(Auth::user()->alamat); ?></textarea>
            </div>

            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="pekerjaan">Pekerjaan</label>
                <input type="text" id="pekerjaan" name="pekerjaan" class="form-control" value="<?php echo e(Auth::user()->pekerjaan); ?>">
              </div>
              <div class="form-group col-md-6">
                <label for="status">Status</label>
                <select name="status" id="status" class="custom-select" required>
                  <option value="" disabled <?php echo e(Auth::user()->status == null ? 'selected' : ''); ?>>Pilih status</option>
                  <option value="Kawin" <?php echo e(Auth::user()->status == 'Kawin' ? 'selected' : ''); ?>>Kawin</option>
                  <option value="Belum Kawin" <?php echo e(Auth::user()->status == 'Belum Kawin' ? 'selected' : ''); ?>>Belum Kawin</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="nama">Nomor HP</label>
              <input type="text" id="nomor_hp" name="nomor_hp" class="form-control" value="<?php echo e(Auth::user()->nomor_hp); ?>">
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/pengguna/profil.blade.php ENDPATH**/ ?>