<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['pengguna']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['pengguna']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="modal fade" id="editPengguna<?php echo e($pengguna->id); ?>" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="varyModalLabel">
                    Edit Pengguna</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('data-user.pengguna.update', $pengguna->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="example-palaceholder">NIK</label>
                        <input type="text" class="form-control" id="nik" name="nik"
                            value="<?php echo e(old('nik', $pengguna->nik ?? '')); ?>" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="example-password">Password <?php echo e(isset($pengguna) ? '(kosongkan jika tidak diubah)' : ''); ?></label>
                        <input type="password" class="form-control" id="password" name="password">
                    </div>
                    <div class="form-group mb-3">
                        <label for="example-password">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama"
                            value="<?php echo e(old('nama', $pengguna->nama ?? '')); ?>" required>
                    </div>
                    <div class="form-group mb-3">
                        <label>Jenis Kelamin</label><br>
                        <div class="form-check form-check-inline mb-3">   
                            <input class="form-check-input" type="radio" name="j_kel" id="laki-laki<?php echo e($pengguna->id); ?>"
                                value="Laki-laki" <?php echo e($pengguna->j_kel === 'Laki-laki' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="laki-laki<?php echo e($pengguna->id); ?>">Laki-laki</label>
                        </div>
                        <div class="form-check form-check-inline mb-3">
                            <input class="form-check-input" type="radio" name="j_kel" id="perempuan<?php echo e($pengguna->id); ?>"
                                value="Perempuan" <?php echo e($pengguna->j_kel === 'Perempuan' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="perempuan<?php echo e($pengguna->id); ?>">Perempuan</label>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="agama">Agama</label>
                            <select name="agama" id="agama" class="custom-select" required>
                                <option value="" disabled <?php echo e($pengguna->agama ? '' : 'selected'); ?>>Pilih agama</option>
                                <option value="Islam" <?php echo e($pengguna->agama == 'Islam' ? 'selected' : ''); ?>>Islam</option>
                                <option value="Kristen" <?php echo e($pengguna->agama == 'Kristen' ? 'selected' : ''); ?>>Kristen</option>
                                <option value="Katolik" <?php echo e($pengguna->agama == 'Katolik' ? 'selected' : ''); ?>>Katolik</option>
                                <option value="Hindu" <?php echo e($pengguna->agama == 'Hindu' ? 'selected' : ''); ?>>Hindu</option>
                                <option value="Buddha" <?php echo e($pengguna->agama == 'Buddha' ? 'selected' : ''); ?>>Buddha</option>
                                <option value="Konghucu" <?php echo e($pengguna->agama == 'Konghucu' ? 'selected' : ''); ?>>Konghucu</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="custom-select" required>
                                <option value="" disabled <?php echo e($pengguna->status ? '' : 'selected'); ?>>Pilih status</option>
                                <option value="Kawin" <?php echo e($pengguna->status == 'Kawin' ? 'selected' : ''); ?>>Kawin</option>
                                <option value="Belum Kawin" <?php echo e($pengguna->status == 'Belum Kawin' ? 'selected' : ''); ?>>Belum Kawin</option>
                                <option value="Cerai Mati" <?php echo e($pengguna->status == 'Cerai Mati' ? 'selected' : ''); ?>>Cerai Mati</option>
                                <option value="Cerai Hidup" <?php echo e($pengguna->status == 'Cerai Hidup' ? 'selected' : ''); ?>>Cerai Hidup</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputCity">Tempat Lahir</label>
                            <input type="text" class="form-control" id="inputCity" name="tmp_lahir"
                                value="<?php echo e(old('tmp_lahir', $pengguna->tmp_lahir ?? '')); ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="date-input<?php echo e($pengguna->id); ?>">Tanggal
                                Lahir</label>
                            <div class="input-group">
                                <input type="text" class="form-control drgpicker" id="date-input<?php echo e($pengguna->id); ?>" name="tgl_lahir"
                                    aria-describedby="button-addon-date<?php echo e($pengguna->id); ?>" value="<?php echo e(old('tgl_lahir', \Carbon\Carbon::parse($pengguna->tgl_lahir)->format('m/d/Y'))); ?>" required>
                                <div class="input-group-append">
                                    <div class="input-group-text" id="button-addon-date<?php echo e($pengguna->id); ?>"><span
                                            class="fe fe-calendar fe-16"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="pekerjaan">Pekerjaan</label>
                        <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" placeholder="Masukkan pekerjaan"
                            value="<?php echo e(old('pekerjaan', $pengguna->pekerjaan)); ?>">
                    </div>


                    <div class="form-group">
                        <label for="nomor_hp">Nomor HP</label>
                        <input type="text" class="form-control" id="nomor_hp" name="nomor_hp" placeholder="Masukkan nomor HP"
                            value="<?php echo e(old('nomor_hp', $pengguna->nomor_hp)); ?>">
                    </div>

                    <div class="form-group">
                        <label for="inputAddress">Alamat</label>
                        <input type="text" class="form-control" id="inputAddress" name="alamat" value="<?php echo e(old('alamat', $pengguna->alamat ?? '')); ?>" required>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn mb-2 btn-danger" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn mb-2 btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/components/edit-pengguna.blade.php ENDPATH**/ ?>