<div>
    
    <div wire:loading.delay wire:target="search" class="text-muted mb-2">
        <i class="spinner-border spinner-border-sm"></i> Mencari...
    </div>

    
    <div class="toolbar row mb-3 align-items-center">
        <div class="col-md-6 d-flex">
            
            <input wire:model.defer="search"
                   type="text"
                   class="form-control"
                   placeholder="Cari Username..."
                   style="max-width: 250px;">

            
            <button wire:click="$refresh"
                    class="btn btn-secondary ml-2"
                    style="height: calc(1.5em + .75rem + 2px);">
                Cari
            </button>
        </div>

        
        <div class="col-md-6 text-right">
            <form wire:submit.prevent="bulkDelete" class="d-inline">
                <button type="submit" class="btn btn-danger"
                        onclick="return confirm('Yakin hapus data terpilih?')"
                        wire:loading.attr="disabled"
                        wire:target="bulkDelete">
                    <span wire:loading.remove wire:target="bulkDelete">
                        <i class="fe fe-trash-2"></i>
                    </span>
                    <span wire:loading wire:target="bulkDelete">
                        <i class="spinner-border spinner-border-sm"></i>
                    </span>
                </button>
            </form>

            <button type="button" class="btn btn-primary ml-2" data-toggle="modal" data-target="#tambahAdmin">
                Tambah +
            </button>
        </div>
        <?php if (isset($component)) { $__componentOriginaldc6c47b2dbde2c874161740878d1c990 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6c47b2dbde2c874161740878d1c990 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $attributes = $__attributesOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__attributesOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6c47b2dbde2c874161740878d1c990)): ?>
<?php $component = $__componentOriginaldc6c47b2dbde2c874161740878d1c990; ?>
<?php unset($__componentOriginaldc6c47b2dbde2c874161740878d1c990); ?>
<?php endif; ?>
    </div>


    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th><input type="checkbox" wire:model="selectAllCheckbox"></th>
                <th>ID</th>
                <th>Username</th>
                <th>Password</th>
                <th>Role</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><input type="checkbox" wire:model="selectedAdmins" value="<?php echo e($admin->id); ?>"></td>
                    <td><?php echo e($admin->id); ?></td>
                    <td><?php echo e($admin->username); ?></td>
                    <td>••••••••</td>
                    <td><?php echo e(ucfirst($admin->role)); ?></td>
                    <td>
                        <button class="btn btn-sm btn-warning" data-toggle="modal" data-target="#adminEdit<?php echo e($admin->id); ?>">
                            Edit
                        </button>
                        <?php if (isset($component)) { $__componentOriginal933b4bb6a186813386ae60040f5d54f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal933b4bb6a186813386ae60040f5d54f4 = $attributes; } ?>
<?php $component = App\View\Components\EditAdmin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('edit-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\EditAdmin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal933b4bb6a186813386ae60040f5d54f4)): ?>
<?php $attributes = $__attributesOriginal933b4bb6a186813386ae60040f5d54f4; ?>
<?php unset($__attributesOriginal933b4bb6a186813386ae60040f5d54f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal933b4bb6a186813386ae60040f5d54f4)): ?>
<?php $component = $__componentOriginal933b4bb6a186813386ae60040f5d54f4; ?>
<?php unset($__componentOriginal933b4bb6a186813386ae60040f5d54f4); ?>
<?php endif; ?>

                        <form action="<?php echo e(route('data-user.admin.destroy', $admin->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger"
                                    onclick="return confirm('Hapus Admin ini?')">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center text-muted">Tidak ada data admin.</td>
                </tr>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    
    <div class="d-flex justify-content-end mt-3">
        <?php echo e($admins->links()); ?>

    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    Livewire.on('show-success', ({ message }) => {
    const alert = document.createElement('div');
    alert.className = 'alert alert-success alert-dismissible fade show mt-3';
    alert.innerHTML = `
        ${message}
        <button type="button" class="close" data-dismiss="alert">&times;</button>
    `;

    const container = document.querySelector('.main-content .container-fluid');
    if (container) container.prepend(alert);

    setTimeout(() => {
        $(alert).alert('close');
    }, 3000);
});


</script>

<?php $__env->stopPush(); ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/livewire/admin-search.blade.php ENDPATH**/ ?>