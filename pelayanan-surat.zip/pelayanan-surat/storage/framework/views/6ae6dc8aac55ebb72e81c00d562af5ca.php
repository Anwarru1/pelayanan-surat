<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<!--Main Content-->
      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Pengajuan Surat</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <div class="card shadow">
                    <div class="card-body">
                      <?php if(session('success')): ?>
                        <div class="alert alert-success">
                          <?php echo e(session('success')); ?>

                        </div>
                      <?php endif; ?>
                      <?php if($errors->any()): ?>
                          <div class="alert alert-danger">
                              <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                          </div>
                      <?php endif; ?>
                      <!-- table -->
                      <table class="table datatables" id="dataTable-1">
                        <thead class="thead-dark">
                          <tr>
                            <th></th>
                            <th>No.</th>
                            <th>Jenis Surat</th>
                            <th>Pemohon</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td>
                              <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input">
                                <label class="custom-control-label"></label>
                              </div>
                            </td>
                            <td><?php echo e($pengajuan->count() - $loop->index); ?></td>
                            <td><?php echo e($p->jenisSurat->nama_jenis_surat); ?></td>
                            <td><?php echo e($p->pengguna->nama); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($p->tanggal)->translatedFormat('l, d F Y')); ?></td>
                            <td>
                              <?php if($p->status == 'menunggu'): ?>
                                <span class="badge badge-warning">Menunggu</span>
                              <?php elseif($p->status == 'diproses'): ?>
                                  <span class="badge badge-info">Diproses</span>
                              <?php elseif($p->status == 'diterima'): ?>
                                  <span class="badge badge-success">Selesai</span>
                              <?php else: ?>
                                  <span class="badge badge-danger">Ditolak</span>
                              <?php endif; ?>
                              </td>
                              <td>
                                <!-- Tombol Kelola Surat -->
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#kelolaModal<?php echo e($p->id); ?>">
                                  <i class="fe fe-edit"></i> Kelola
                                </button>
                                <?php if (isset($component)) { $__componentOriginal09b8884b3140d174316ab9154a1561dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal09b8884b3140d174316ab9154a1561dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-pengajuan','data' => ['p' => $p]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detail-pengajuan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['p' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal09b8884b3140d174316ab9154a1561dd)): ?>
<?php $attributes = $__attributesOriginal09b8884b3140d174316ab9154a1561dd; ?>
<?php unset($__attributesOriginal09b8884b3140d174316ab9154a1561dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal09b8884b3140d174316ab9154a1561dd)): ?>
<?php $component = $__componentOriginal09b8884b3140d174316ab9154a1561dd; ?>
<?php unset($__componentOriginal09b8884b3140d174316ab9154a1561dd); ?>
<?php endif; ?>
                              </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> 
      <!-- main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/admin/pengajuan-surat.blade.php ENDPATH**/ ?>