<!-- Modal -->
<div class="modal fade" id="tambahJenisSurat" tabindex="-1" role="dialog" aria-labelledby="labelTambahJenisSurat" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="labelTambahJenisSurat">Tambah Jenis Surat</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span>&times;</span></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('jenis-surat.store')); ?>" method="POST" enctype="multipart/form-data" id="formJenisSurat">
                    <?php echo csrf_field(); ?>

                    <!-- Kode Surat -->
                    <div class="form-group">
                        <label for="kode_surat">Kode Surat</label>
                        <input type="text" id="kode_surat" name="kode_surat"
                            class="form-control <?php $__errorArgs = ['kode_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            placeholder="Massukkan kode surat "
                            value="<?php echo e(old('kode_surat')); ?>">
                        <?php $__errorArgs = ['kode_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="form-text text-muted">Contoh: 470, 350, 600</small>
                    </div>

                    <!-- Nama Jenis Surat -->
                    <div class="form-group">
                        <label for="nama_jenis_surat">Nama Jenis Surat</label>
                        <input type="text" id="nama_jenis_surat" name="nama_jenis_surat"
                            class="form-control <?php $__errorArgs = ['nama_jenis_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            placeholder="Masukkan nama jenis surat"
                            value="<?php echo e(old('nama_jenis_surat')); ?>">
                        <?php $__errorArgs = ['nama_jenis_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="form-text text-muted">Contoh: Surat Pengantar E-KTP</small>
                    </div>

                    <!-- Syarat Surat -->
                    <div class="form-group">
                        <label for="syarat_surat">Syarat Surat</label>
                        <div id="syarat-container">
                            <div class="input-group mb-2">
                                <input type="text" class="form-control" name="syarat[]" placeholder="Masukkan syarat">
                                <div class="input-group-append">
                                    <button class="btn btn-outline-danger remove-syarat" type="button"><i class="fe fe-trash-2"></i></button>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-sm btn-dark" id="add-syarat">
                            <i class="fe fe-plus"></i> Tambah Syarat
                        </button>
                        <?php $__errorArgs = ['syarat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger" style="font-size: 80%"><strong><?php echo e($message); ?></strong></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Keterangan Default -->
                    <div class="form-group">
                        <label for="keterangan_default">Keterangan Default</label>
                        <textarea name="keterangan_default" id="keterangan_default" class="form-control" rows="3"><?php echo e(old('keterangan_default')); ?></textarea>
                        <small class="form-text text-muted">Keterangan ini akan otomatis muncul saat pengguna memilih jenis surat.</small>
                    </div>

                    <!-- Template Surat -->
                    <div class="form-group">
                        <label for="template">Template Surat</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input <?php $__errorArgs = ['template'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="template" name="template" accept=".docx">
                            <label class="custom-file-label" for="template">Pilih file template (DOCX)</label>
                        </div>
                        <?php $__errorArgs = ['template'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="form-text text-muted">Format file .docx (Microsoft Word)</small>
                    </div>

                    <!-- Footer -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const container = document.getElementById('syarat-container');
        const addBtn = document.getElementById('add-syarat');
        const form = document.getElementById('formJenisSurat');

        addBtn.addEventListener('click', function () {
            const inputGroup = document.createElement('div');
            inputGroup.className = 'input-group mb-2';
            inputGroup.innerHTML = `
                <input type="text" class="form-control" name="syarat[]" placeholder="Masukkan syarat">
                <div class="input-group-append">
                    <button class="btn btn-outline-danger remove-syarat" type="button"><i class="fe fe-trash-2"></i></button>
                </div>
            `;
            container.appendChild(inputGroup);
        });

        container.addEventListener('click', function (e) {
            if (e.target.closest('.remove-syarat')) {
                const group = e.target.closest('.input-group');
                if (container.children.length > 1) group.remove();
            }
        });

        form.addEventListener('submit', function (e) {
            form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));

            let valid = true;
            ['kode_surat', 'nama_jenis_surat'].forEach(id => {
                const el = document.getElementById(id);
                if (!el.value.trim()) {
                    el.classList.add('is-invalid');
                    valid = false;
                }
            });

            container.querySelectorAll('input[name="syarat[]"]').forEach(input => {
                if (!input.value.trim()) {
                    input.classList.add('is-invalid');
                    valid = false;
                }
            });

            if (!valid) {
                e.preventDefault();
            }
        });
    });
    </script>

    
<?php $__env->stopPush(); ?>
<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/components/tambah-jenis-surat.blade.php ENDPATH**/ ?>