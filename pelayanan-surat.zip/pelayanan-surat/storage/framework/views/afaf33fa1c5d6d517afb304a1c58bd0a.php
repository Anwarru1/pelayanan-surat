<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['s']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['s']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="modal fade" id="editJenisSurat<?php echo e($s->id); ?>" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="varyModalLabel">Edit Jenis Surat
                    </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('jenis-surat.update', $s->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="example-palaceholder">Kode Surat</label>
                        <input type="text" id="kode_surat" class="form-control <?php $__errorArgs = ['kode_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kode_surat"
                            value="<?php echo e(old('kode_surat', $s->kode_surat)); ?>" required>
                        <?php $__errorArgs = ['kode_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="example-palaceholder">Nama Jenis Surat</label>
                        <input type="text" id="nama_jenis_surat" class="form-control <?php $__errorArgs = ['nama_jenis_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_jenis_surat"
                            value="<?php echo e(old('nama_jenis_surat', $s->nama_jenis_surat)); ?>" required>
                        <?php $__errorArgs = ['nama_jenis_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label>Syarat Surat</label>
                        <div class="syarat-container" id="syarat-container-<?php echo e($s->id); ?>">
                            <?php $__currentLoopData = old('syarat', $s->syarat); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $syarat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="input-group mb-2">
                            <input type="text" name="syarat[]" class="form-control" value="<?php echo e($syarat); ?>" required>
                            <div class="input-group-append">
                                <button type="button" class="btn btn-danger remove-syarat"><i class="fe fe-trash-2"></i></button>
                            </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-dark add-syarat" data-target="#syarat-container-<?php echo e($s->id); ?>">
                            <i class="fe fe-plus"></i> Tambah Syarat
                        </button>
                        <?php $__errorArgs = ['syarat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger" style="font-size: 80%;">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="keterangan_default">Keterangan Default</label>
                        <textarea name="keterangan_default" id="keterangan_default" class="form-control" rows="3"><?php echo e(old('keterangan_default', $s->keterangan_default ?? '')); ?></textarea>
                        <small class="form-text text-muted">Keterangan ini akan otomatis muncul saat pengguna memilih jenis surat.</small>
                    </div>
                    <div class="form-group">
                        <label for="template">Template Surat</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input <?php $__errorArgs = ['template'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="template" name="template">
                            <label class="custom-file-label" for="template">
                                <?php echo e($s->template ? basename($s->template) : 'Pilih file template (.docx)'); ?>

                            </label>
                            <?php $__errorArgs = ['template'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <small class="form-text text-muted">
                            Biarkan kosong jika tidak ingin mengubah template. 
                            <?php if($s->template): ?>
                                <a href="<?php echo e(Storage::url($s->template)); ?>" target="_blank">Download template saat ini</a>
                            <?php endif; ?>
                        </small>
                    </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn mb-2 btn-danger" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn mb-2 btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        // Tambah syarat
        $('.add-syarat').off('click').on('click', function () {
            const targetSelector = $(this).data('target');
            const container = $(targetSelector);

            const html = `
                <div class="input-group mb-2">
                    <input type="text" name="syarat[]" class="form-control" required>
                    <div class="input-group-append">
                        <button type="button" class="btn btn-danger remove-syarat">
                            <i class="fe fe-trash-2"></i>
                        </button>
                    </div>
                </div>
            `;

            container.append(html);
        });

        // Hapus syarat
        $(document).on('click', '.remove-syarat', function () {
        const group = $(this).closest('.input-group');
        
        // Cari container berdasarkan konteks modal aktif
        const container = $(this).closest('.syarat-container, #syarat-container');

        // Hitung hanya input syarat yang masih ada dalam container tersebut
        const totalSyarat = container.find('input[name="syarat[]"]').length;

        if (totalSyarat > 1) {
            group.remove();
        }
        });

        // File input display filename
        $(document).on('change', '.custom-file-input', function () {
            const fileName = $(this).val().split('\\').pop();
            $(this).next('.custom-file-label').addClass("selected").html(fileName);
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php /**PATH D:\laragon\www\pelayanan-surat\resources\views/components/edit-jenis-surat.blade.php ENDPATH**/ ?>